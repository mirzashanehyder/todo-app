import React from 'react'

function RouterError() {
  return (
    <div>
      <h1 className="text-danger text-center">Invalid path</h1>
    </div>
  )
}

export default RouterError
