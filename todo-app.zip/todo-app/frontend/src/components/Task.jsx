import React from 'react'

function Task() {
  return (
    <div>
      task
    </div>
  )
}

export default Task
